library(shiny)
library(rAmCharts)
library(colourpicker)

# chargement des fonctions

# chargement des donnees globales